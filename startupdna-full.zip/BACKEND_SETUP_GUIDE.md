# StartupDNA 后端搭建指南

## 一、项目概述

StartupDNA 是一个创业DNA测试与分析平台，当前为纯前端单页应用（SPA），部署在 GitHub Pages。
本文档描述后端服务的搭建需求，用于解决纯前端架构的安全和功能限制。

### 当前前端技术栈
- 纯HTML/CSS/JS单文件应用（index.html）
- Hash路由（#home, #test, #ai 等）
- localStorage 存储用户数据
- MiniMax API（AI分析，当前密钥硬编码在前端）

### 为什么需要后端
1. **API密钥安全**：AI API密钥不能暴露在前端
2. **用户认证**：当前密码哈希极不安全（djb2算法）
3. **数据持久化**：localStorage不可靠，清除浏览器数据即丢失
4. **内测码系统**：前端验证可被绕过
5. **多设备同步**：用户数据绑定在单个浏览器

---

## 二、技术选型建议

### 方案A：Node.js + Express（推荐，学习成本低）
```
后端框架：Express.js / NestJS
数据库：PostgreSQL（主库）+ Redis（缓存/会话）
ORM：Prisma
认证：JWT + bcrypt
文件存储：本地 / MinIO
实时通讯：Socket.IO（可选）
部署：Docker + Nginx
```

### 方案B：Python + FastAPI
```
后端框架：FastAPI
数据库：PostgreSQL + Redis
ORM：SQLAlchemy
认证：JWT + bcrypt
部署：Docker + Nginx
```

### 方案C：Serverless（最低成本）
```
函数计算：Vercel Functions / Cloudflare Workers
数据库：Supabase（PostgreSQL）/ PlanetScale
认证：Supabase Auth / Clerk
存储：Cloudflare R2
```

---

## 三、数据库设计

### 3.1 用户表 (users)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| nickname | VARCHAR(50) UNIQUE | 昵称 |
| email | VARCHAR(255) UNIQUE NULLABLE | 邮箱 |
| password_hash | VARCHAR(255) | bcrypt哈希 |
| avatar_url | VARCHAR(500) | 头像URL |
| bio | TEXT | 个人简介 |
| role | ENUM('admin','user') | 角色 |
| invite_code_id | UUID NULLABLE | 使用的内测码 |
| created_at | TIMESTAMP | 创建时间 |
| updated_at | TIMESTAMP | 更新时间 |
| last_login | TIMESTAMP | 最后登录 |

### 3.2 内测码表 (invite_codes)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| code_hash | VARCHAR(64) | SHA-256哈希（不存明文） |
| code_type | ENUM('once','limited','timed') | 类型 |
| max_uses | INT | 最大使用次数 |
| used_count | INT DEFAULT 0 | 已使用次数 |
| expires_at | TIMESTAMP NULLABLE | 过期时间 |
| created_by | UUID | 创建者（管理员） |
| is_revoked | BOOLEAN DEFAULT false | 是否撤销 |
| created_at | TIMESTAMP | 创建时间 |

### 3.3 测试结果表 (test_results)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| user_id | UUID FK | 用户ID |
| personality_type | VARCHAR(20) | 人格类型代码 |
| scores | JSONB | 各维度分数 |
| answers | JSONB | 答题记录 |
| created_at | TIMESTAMP | 创建时间 |

### 3.4 创意表 (ideas)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| user_id | UUID FK | 用户ID |
| title | VARCHAR(200) | 创意标题 |
| content | JSONB | 各阶段内容 |
| is_deleted | BOOLEAN DEFAULT false | 软删除 |
| created_at | TIMESTAMP | 创建时间 |
| updated_at | TIMESTAMP | 更新时间 |

### 3.5 AI分析记录表 (ai_analyses)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| user_id | UUID FK | 用户ID |
| idea_text | TEXT | 创业想法 |
| analysis_type | VARCHAR(50) | 分析类型 |
| result | JSONB | AI分析结果 |
| created_at | TIMESTAMP | 创建时间 |

### 3.6 每日挑战记录表 (challenge_records)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| user_id | UUID FK | 用户ID |
| day_number | INT | 第几天 |
| answer | TEXT | 用户回答 |
| ai_feedback | TEXT NULLABLE | AI点评 |
| created_at | TIMESTAMP | 创建时间 |

### 3.7 用户收藏表 (favorites)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| user_id | UUID FK | 用户ID |
| item_type | VARCHAR(20) | 类型（knowledge/idea等） |
| item_id | VARCHAR(100) | 项目ID |
| created_at | TIMESTAMP | 创建时间 |

### 3.8 Go/No-Go评分记录表 (scorer_records)
| 字段 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| user_id | UUID FK | 用户ID |
| scores | JSONB | 各维度分数 |
| overall | FLOAT | 总分 |
| verdict | VARCHAR(10) | GO/MAYBE/NO-GO |
| created_at | TIMESTAMP | 创建时间 |

---

## 四、API 接口设计

### 4.1 认证模块
```
POST   /api/auth/register     # 注册（需内测码）
POST   /api/auth/login        # 登录
POST   /api/auth/logout       # 登出
POST   /api/auth/refresh      # 刷新Token
POST   /api/auth/forgot-password  # 发送重置邮件
POST   /api/auth/reset-password   # 重置密码
GET    /api/auth/me           # 获取当前用户信息
PUT    /api/auth/profile      # 更新个人资料
POST   /api/auth/avatar       # 上传头像
```

### 4.2 内测码模块（管理员）
```
POST   /api/admin/invite-codes        # 创建内测码
GET    /api/admin/invite-codes        # 查看所有内测码
DELETE /api/admin/invite-codes/:id     # 撤销内测码
POST   /api/admin/invite-codes/batch  # 批量生成
GET    /api/admin/stats               # 统计面板
POST   /api/invite-codes/validate     # 验证内测码（公开）
```

### 4.3 测试模块
```
POST   /api/tests/submit       # 提交测试结果
GET    /api/tests/results      # 获取我的测试结果
GET    /api/tests/results/:id  # 获取单个结果详情
```

### 4.4 AI分析模块（代理调用）
```
POST   /api/ai/analyze        # AI创业分析
POST   /api/ai/swot           # AI生成SWOT
POST   /api/ai/canvas         # AI填充Canvas
POST   /api/ai/debate         # AI红蓝对抗
POST   /api/ai/challenge-feedback  # AI挑战点评
POST   /api/ai/recommend      # AI知识推荐
```

### 4.5 创意模块
```
GET    /api/ideas              # 获取我的创意列表
POST   /api/ideas              # 创建创意
PUT    /api/ideas/:id          # 更新创意
DELETE /api/ideas/:id          # 删除创意
```

### 4.6 挑战模块
```
GET    /api/challenges/today   # 获取今日挑战
POST   /api/challenges/submit  # 提交挑战答案
GET    /api/challenges/records # 获取我的挑战记录
```

### 4.7 评分模块
```
POST   /api/scorer/submit     # 提交评分
GET    /api/scorer/records    # 获取评分记录
```

### 4.8 收藏模块
```
GET    /api/favorites          # 获取收藏列表
POST   /api/favorites          # 添加收藏
DELETE /api/favorites/:id      # 取消收藏
```

### 4.9 数据导出
```
GET    /api/export/all         # 导出所有数据
GET    /api/export/pdf/:type   # 导出PDF报告
```

---

## 五、安全要求

### 5.1 认证安全
- 密码使用 bcrypt（cost factor >= 12）哈希存储
- JWT Token 有效期 7天，Refresh Token 30天
- 登录失败 5 次后锁定 15 分钟
- 密码最低 8 位，需包含大小写和数字

### 5.2 API安全
- 所有接口（除注册/登录/内测码验证）需 JWT 认证
- 速率限制：每IP每分钟 60 次请求
- AI接口额外限制：每用户每天 20 次
- CORS 仅允许前端域名
- 输入验证和SQL注入防护（使用ORM参数化查询）
- XSS防护：所有输出转义

### 5.3 内测码安全
- 仅存储 SHA-256 哈希值
- 验证+消费+创建用户在同一数据库事务中完成
- 支持三种类型：一次性码、限量码、限时码
- 管理员可撤销已发放的码

### 5.4 数据安全
- 敏感数据（密码哈希、邮箱）加密存储
- API响应不返回密码哈希
- 数据导出时过滤敏感字段
- 定期备份数据库

---

## 六、部署架构

### 6.1 开发环境
```
docker-compose.yml:
  - PostgreSQL 15
  - Redis 7
  - Node.js (Express + Prisma)
  - Nginx (反向代理)
```

### 6.2 生产环境
```
推荐云服务：
- 轻量：Railway / Render / Fly.io
- 国内：阿里云轻量服务器 / 腾讯云轻量
- 专业：AWS EC2 / 阿里云ECS

Nginx配置：
- HTTPS（Let's Encrypt）
- Gzip压缩
- 静态文件缓存
- API反向代理
```

### 6.3 CI/CD
```
GitHub Actions:
1. push到main分支触发
2. 运行测试
3. 构建Docker镜像
4. 部署到服务器
```

---

## 七、前端对接改造要点

### 7.1 需要修改的前端函数
| 函数 | 当前行为 | 改造后 |
|------|---------|--------|
| doRegister() | localStorage存储 | POST /api/auth/register |
| doLogin() | localStorage验证 | POST /api/auth/login |
| doLogout() | 删除localStorage | POST /api/auth/logout |
| doResetPassword() | 直接修改localStorage | POST /api/auth/reset-password |
| callAI() | 直接调用MiniMax API | POST /api/ai/* |
| submitTest() | localStorage存储 | POST /api/tests/submit |
| validateInviteCode() | 前端数组验证 | POST /api/invite-codes/validate |

### 7.2 需要新增的前端逻辑
- JWT Token 管理（存储在localStorage，请求时携带Authorization头）
- Token过期自动刷新
- API请求统一封装（fetch/axios拦截器）
- 网络错误统一处理
- 加载状态管理

### 7.3 渐进式迁移策略
1. **阶段一**：搭建后端 + AI代理接口（解决API密钥泄露）
2. **阶段二**：迁移用户认证（注册/登录/密码重置）
3. **阶段三**：迁移数据存储（测试结果、创意、挑战记录等）
4. **阶段四**：迁移内测码系统到后端验证
5. **阶段五**：添加微信/GitHub第三方登录

---

## 八、内测码初始数据

当前前端定义了100个内测码，格式为 an + 三位数字（步长5）：
```
an000, an005, an010, an015, an020, an025, an030, an035, an040, an045,
an050, an055, an060, an065, an070, an075, an080, an085, an090, an095,
an100, an105, an110, an115, an120, an125, an130, an135, an140, an145,
an150, an155, an160, an165, an170, an175, an180, an185, an190, an195,
an200, an205, an210, an215, an220, an225, an230, an235, an240, an245,
an250, an255, an260, an265, an270, an275, an280, an285, an290, an295,
an300, an305, an310, an315, an320, an325, an330, an335, an340, an345,
an350, an355, an360, an365, an370, an375, an380, an385, an390, an395,
an400, an405, an410, an415, an420, an425, an430, an435, an440, an445,
an450, an455, an460, an465, an470, an475, an480, an485, an490, an495
```

后端初始化脚本应将这些码的SHA-256哈希值写入 invite_codes 表。

---

## 九、环境变量配置

```env
# 数据库
DATABASE_URL=postgresql://user:password@localhost:5432/startupdna
REDIS_URL=redis://localhost:6379

# JWT
JWT_SECRET=your-super-secret-key-change-this
JWT_EXPIRES_IN=7d
JWT_REFRESH_EXPIRES_IN=30d

# AI
MINIMAX_API_KEY=sk-xxx
MINIMAX_API_ENDPOINT=https://api.minimax.io/v1/text/chatcompletion_v2
MINIMAX_MODEL=MiniMax-Text-01

# 邮件（密码重置）
SMTP_HOST=smtp.qq.com
SMTP_PORT=465
SMTP_USER=your-email@qq.com
SMTP_PASS=your-smtp-password

# 前端
FRONTEND_URL=https://an-an-525.github.io/questionnaire-app
CORS_ORIGIN=https://an-an-525.github.io

# 注册模式: open / invite_only / closed
REG_MODE=invite_only
```

---

## 十、快速启动（Node.js方案）

```bash
# 1. 创建项目
mkdir startupdna-backend && cd startupdna-backend
npm init -y
npm install express prisma @prisma/client bcryptjs jsonwebtoken cors dotenv
npm install -D nodemon typescript @types/express @types/bcryptjs @types/jsonwebtoken

# 2. 初始化Prisma
npx prisma init
# 编辑 prisma/schema.prisma 添加上面的表结构

# 3. 创建数据库
npx prisma migrate dev --name init

# 4. 创建种子数据（内测码）
# 编写 prisma/seed.ts 导入100个内测码

# 5. 启动开发服务器
npx prisma studio  # 可视化数据库管理
npm run dev        # 启动API服务器
```

---

## 十一、项目文件结构建议

```
startupdna-backend/
├── prisma/
│   ├── schema.prisma      # 数据库模型
│   ├── seed.ts            # 种子数据
│   └── migrations/        # 数据库迁移
├── src/
│   ├── index.ts           # 入口
│   ├── config/
│   │   └── env.ts         # 环境变量
│   ├── middleware/
│   │   ├── auth.ts        # JWT认证中间件
│   │   ├── rateLimit.ts   # 速率限制
│   │   └── errorHandler.ts # 错误处理
│   ├── routes/
│   │   ├── auth.ts        # 认证路由
│   │   ├── admin.ts       # 管理员路由
│   │   ├── tests.ts       # 测试路由
│   │   ├── ai.ts          # AI代理路由
│   │   ├── ideas.ts       # 创意路由
│   │   ├── challenges.ts  # 挑战路由
│   │   ├── scorer.ts      # 评分路由
│   │   └── favorites.ts   # 收藏路由
│   ├── services/
│   │   ├── ai.service.ts  # AI调用服务
│   │   ├── invite.service.ts # 内测码服务
│   │   └── email.service.ts  # 邮件服务
│   └── utils/
│       ├── hash.ts        # 密码哈希
│       ├── jwt.ts         # Token管理
│       └── validation.ts  # 输入验证
├── docker-compose.yml
├── Dockerfile
├── .env.example
├── .gitignore
├── package.json
└── tsconfig.json
```
