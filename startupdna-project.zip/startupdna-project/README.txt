# StartupDNA - 创业DNA平台

## 📁 项目结构

```
startupdna-project/
├── README.txt              ← 你正在看的说明文件
├── frontend/
│   ├── index.html          ← 主页面（354KB，包含全部前端代码）
│   └── manifest.json       ← PWA配置
├── backend/
│   ├── server.js           ← 后端服务器（32KB）
│   ├── package.json        ← 依赖配置
│   └── .env.example        ← 环境变量模板
├── deploy/
│   ├── startupdna-deploy.zip  ← 部署包（拖到Netlify即可上线）
│   └── deploy-github.sh    ← GitHub Pages一键部署脚本
└── apk/
    └── StartupDNA.apk      ← Android安装包
```

## 🚀 快速开始

### 方式一：直接打开（最简单）
1. 用浏览器打开 `frontend/index.html`
2. AI功能使用内置离线引擎，无需网络即可使用
3. 如需在线AI增强，需部署到外网（见方式二）

### 方式二：部署到外网（推荐，AI功能更强）
1. 打开 https://app.netlify.com/drop
2. 把 `deploy/startupdna-deploy.zip` 解压后的文件夹拖进去
3. 自动获得外网地址，在线AI（MiniMax M2.7）自动启用

### 方式三：本地运行后端
```bash
cd backend
npm install
cp .env.example .env  # 编辑.env填入你的MiniMax API密钥
node server.js
# 打开 http://localhost:3000/startupdna-optimized.html
```

### 方式四：安装Android APK
1. 把 `apk/StartupDNA.apk` 传到手机
2. 设置 → 安全 → 允许安装未知来源
3. 点击安装即可使用

## 🤖 AI功能说明

AI采用三级架构：
1. **在线API**（MiniMax M2.7）— 部署到外网后自动启用，回答更智能
2. **后端代理** — 通过本地后端转发API请求
3. **离线引擎** — 内置16个行业知识库+分析框架，无需网络

离线引擎支持：
- 创业想法评估
- 竞品分析
- SWOT分析
- 商业画布（Lean Canvas）
- 商业计划书（BP）框架
- Go/No-Go辩论
- 项目评分
- 行动计划生成

## 🔑 MiniMax API配置

如需启用在线AI，在 `.env` 文件中配置：
```
AI_PROVIDER=minimax
MINIMAX_API_KEY=你的API密钥
MINIMAX_MODEL=MiniMax-M2.7
```

免费获取API密钥：https://platform.minimaxi.com

## 📱 功能模块

- **AI助手** — 智能创业咨询对话
- **一键分析** — 输入想法，自动生成完整分析报告
- **人格测试** — 创业者性格评估（DISC模型）
- **知识库** — 创业知识收藏与学习
- **每日挑战** — 创业能力训练
- **竞品分析** — 全面竞品对比
- **商业画布** — Lean Canvas可视化
- **BP生成** — 商业计划书自动生成
- **用户系统** — 注册/登录/个人中心

## 🛠 技术栈

- 前端：纯HTML/CSS/JavaScript（无框架依赖）
- 后端：Node.js + Express + SQLite
- AI：MiniMax M2.7 + 离线规则引擎
- 部署：静态托管（Netlify/Vercel/GitHub Pages）
